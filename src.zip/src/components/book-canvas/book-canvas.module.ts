import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { BookCanvasComponent } from './book-canvas';

@NgModule({
  declarations: [
    BookCanvasComponent,
  ],
  imports: [
    IonicPageModule.forChild(BookCanvasComponent),
  ],
  exports: [
    BookCanvasComponent
  ]
})
export class BookCanvasComponentModule {}
