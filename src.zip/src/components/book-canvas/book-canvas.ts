import { Component, ViewChild, ElementRef, Renderer, Input } from '@angular/core';
import { Platform } from 'ionic-angular';
import { BookDrawer } from '../../utils/book-drawer';

@Component({
	selector: 'book-canvas',
	templateUrl: 'book-canvas.html'
})
export class BookCanvasComponent {

	@Input() textBlock: string;
	@Input() startIndex: number;
	@ViewChild('bookCanvas') canvasElement: ElementRef;

	canvas: any;
	drawer: BookDrawer;

	constructor(public platform: Platform, public renderer: Renderer) {
	}

	ngAfterViewInit() {

		this.canvas = this.canvasElement.nativeElement;

		this.renderer.setElementAttribute(this.canvas, 'width', '' + this.platform.width());
		this.renderer.setElementAttribute(this.canvas, 'height', '' + this.platform.height());

		this.canvas.width = this.platform.width();
		this.canvas.height = this.platform.height();

		this.drawer = new BookDrawer(this.canvas);
		this.drawer.drawText(this.textBlock, this.startIndex);
	}

	onTouchStart(event: TouchEvent) {
	}

	onTouchMove(event: TouchEvent) {
	}

	onTouchEnd(event: TouchEvent) {
	}
}
