
export const MARGIN_X: number = 20;
export const MARGIN_Y: number = 20;
export const FONT_SIZE: number = 18;
export const FONT_COLOR = '#666666';

export class BookDrawer {

	contentWidth: number;
	lineHeight: number;
	canvasHeight: number;
	maxRows: number;

	constructor(private canvas: any) {

		this.contentWidth = this.canvas.width - MARGIN_X * 2 - FONT_SIZE;

		this.lineHeight = Math.ceil(FONT_SIZE * 1.2);
		this.canvasHeight = this.canvas.height;

		this.maxRows = Math.floor((this.canvasHeight - MARGIN_Y * 2) / this.lineHeight);
	}

	drawText(text: string, startIndex: number) {

		let context = this.canvas.getContext('2d');

		context.fillStyle = FONT_COLOR;
		context.font = "" + FONT_SIZE + "px sans-serif";;
		context.textBaseline = 'top';

		let line = '';
		let row = 0;

		for (let i = startIndex; i < text.length; i++) {

			let nextChar = text[i];

			if (context.measureText(line + nextChar).width < this.contentWidth) {
				line += nextChar;
				continue;
			}

			i--;

			if (this.isPunctuated(nextChar)) {
				line = line.substring(0, line.length - 1);
				i--;
			}

			context.fillText(line, MARGIN_X, this.lineHeight * row + MARGIN_Y);

			if (row >= this.maxRows) {
				break;
			}

			line = '';
			row++;
		}

		if (row < this.maxRows && line.length > 0) {
			context.fillText(line, MARGIN_X, this.lineHeight * row + MARGIN_Y);
		}
	}

	isPunctuated(c): boolean {
		return ",.?!，。？！".indexOf(c) > -1;
	}
}